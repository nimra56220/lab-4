#include <iostream>

class Node {
public:
    int data;
    Node* prev;
    Node* next;
    Node(int val) : data(val), prev(nullptr), next(nullptr) {}
};

class DoublyLinkedList {
private:
    Node* head;
    Node* tail;
public:
    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    // Function to add a node to the end of the list
    void append(int val) {
        Node* newNode = new Node(val);
        if (!head) {
            head = newNode;
            tail = newNode;
        } else {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
    }

    // Function to display the elements of the list forward
    void displayForward() {
        Node* current = head;
        while (current) {
            std::cout << current->data << " ";
            current = current->next;
        }
        std::cout << std::endl;
    }

    // Function to display the elements of the list backward
    void displayBackward() {
        Node* current = tail;
        while (current) {
            std::cout << current->data << " ";
            current = current->prev;
        }
        std::cout << std::endl;
    }

    // Function to delete a node by its value
    void deleteNode(int val) {
        Node* current = head;
        while (current) {
            if (current->data == val) {
                if (current->prev) {
                    current->prev->next = current->next;
                } else {
                    head = current->next;
                }
                if (current->next) {
                    current->next->prev = current->prev;
                } else {
                    tail = current->prev;
                }
                delete current;
                return;
            }
            current = current->next;
        }
    }
};

int main() {
    DoublyLinkedList dll;
    
    dll.append(1);
    dll.append(2);
    dll.append(3);
    
    std::cout << "Forward: ";
    dll.displayForward();
    
    std::cout << "Backward: ";
    dll.displayBackward();
    
    dll.deleteNode(2);
    
    std::cout << "After deleting 2: ";
    dll.displayForward();

    return 0;
}


This program defines a `Node` class to represent individual elements and a `DoublyLinkedList` class to manage the list. It demonstrates appending nodes, displaying the list forward and backward, and deleting nodes by their values.